package gymmanagement;

import javax.swing.*;

public class GymManagement {
    
    public static MainPanel mainPanel; //this is just a glue for the other panels .. use placeholders
    public static DashboardPanel dashboardPanel;
    public static RoomPanel roomPanel; //panel to perform room oriented tasks
    public static EquipmentPanel equipmentPanel; //panel to perform equipment oriented tasks
    public static SchedulePanel schedulePanel; //panel for scheduling

    public static void main(String[] args) {
        //create a window for my interface
        JFrame f;

        mainPanel = new MainPanel();
        dashboardPanel = new DashboardPanel ();
        roomPanel = new RoomPanel(); //create a room panel
        equipmentPanel = new EquipmentPanel(); //create an equipment panel
        schedulePanel = new SchedulePanel (); //create the sheduler panel
        
        mainPanel.dashboardPlaceholder.add(dashboardPanel);
        mainPanel.roomPlaceholder.add(roomPanel); //add the room panel to the placeholder
        mainPanel.equipmentPlaceholder.add(equipmentPanel); //add the equipment panel to the placeholder
        mainPanel.schedulePlaceholder.add(schedulePanel); //add scheduler panel to the placeholder

        f = new JFrame("Gym Management System");
        f.setLocation(300, 50);
        f.setSize(600, 500);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        f.add(mainPanel);
        f.setVisible(true);
       
    }

    static DashboardPanel getDashboardPanel() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
    




    
 
        


